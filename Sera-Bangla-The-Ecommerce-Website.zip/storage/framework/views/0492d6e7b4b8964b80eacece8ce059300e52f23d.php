<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <?php echo $__env->make('frontend.partials.dashboard_siteber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md-8">
                <div class="d-flex justify-content-between">
                    <h3> <?php echo e($auth_user->name); ?> 's Profile </h3> <a href="<?php echo e(route('auth.user.profile.edit')); ?>" class="btn btn-primary text-white">Update Profile </a>

                </div>
                <table class="table">

                    <tbody>
                    <tr>
                        <td>Name:</td>
                        <td><?php echo e($auth_user->name); ?></td>
                    </tr>


                    <tr>
                        <td>Email:</td>
                        <td><?php echo e($auth_user->email); ?>

                            <?php if($auth_user->email_verified_at != null): ?>
                                  <p class=" bg-success text-white p-1">   Email Verified</p>
                            <?php else: ?>
                                <p class=" bg-danger text-white p-1">   Email Not Verified</p>
                            <?php endif; ?>
                        </td>
                    </tr>

                    <tr>
                        <td>Phone:</td>
                        <td><?php echo e($auth_user->phone); ?>

                            <?php if($auth_user->phone_verified_at != null): ?>
                                <p class=" bg-success text-white p-1">   Phone Verified</p>
                            <?php else: ?>
                                <p class=" bg-danger text-white p-1">   Phone Not Verified</p>
                            <?php endif; ?>

                        </td>
                    </tr>

                    <tr>
                        <td>Gender:</td>
                        <td><?php echo e($auth_user->gender); ?></td>
                    </tr>

                    <tr>
                        <td>Address:</td>
                        <td><?php echo e($auth_user->address); ?></td>
                    </tr>


                    <tr>
                        <td>Image:</td>
                        <td><img height="100px" width="200px" src="<?php echo e($auth_user->image); ?>"></td>
                    </tr>

                    <tr>
                        <td>Profile Status :</td>
                        <td><?php if($auth_user->status == '1'): ?> <a class=" bg-success text-white p-1">Active</a> <?php else: ?>
                                <a class="bg-danger text-white p-1">Inactive</a>                         <p> Your account has been disabled . Please Contact in support team.</p>
                            <?php endif; ?>
                        </td>
                    </tr>


                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Software\Sera-Bangla-The-Ecommerce-Website\resources\views/frontend/user/profile.blade.php ENDPATH**/ ?>