<div class="block block-sidebar">
    <div class="block-sidebar__item">
        <div class="widget-categories widget-categories--location--shop widget"><h4
                class="widget__title"> Profile </h4>
            <ul class="widget-categories__list" data-collapse=""
                data-collapse-opened-class="widget-categories__item--open">

                <li class="widget-categories__item" data-collapse-item="">
                    <div class="widget-categories__row">
                        <a href="<?php echo e(route('auth.user.orders')); ?>"> Orders </a>
                    </div>
                </li>
                <li class="widget-categories__item" data-collapse-item="">
                    <div class="widget-categories__row">
                        <a href="<?php echo e(route('auth.user.profile')); ?>"> Profile </a>
                    </div>
                </li>
                <li class="widget-categories__item" data-collapse-item="">
                    <div class="widget-categories__row">
                        <a href="<?php echo e(route('auth.user.email.verify')); ?>"> Email Verify </a>
                    </div>
                </li>
                <li class="widget-categories__item" data-collapse-item="">
                    <div class="widget-categories__row">
                        <a href="<?php echo e(route('auth.user.logout')); ?>">Logout</a>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Software\Sera-Bangla-The-Ecommerce-Website\resources\views/frontend/partials/dashboard_siteber.blade.php ENDPATH**/ ?>