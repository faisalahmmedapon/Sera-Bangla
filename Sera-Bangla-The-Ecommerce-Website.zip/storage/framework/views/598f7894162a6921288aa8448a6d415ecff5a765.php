<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto mt-4 mt-md-0">
                <div class="card flex-grow-1 mb-0">
                    <div class="card-body">
                        <h3 class="card-title">Register</h3>
                        <form action="<?php echo e(route('auth.user.register')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label> Name </label>
                                <input name="name" type="text" value="<?php echo e(old('name')); ?>"  class="form-control" placeholder="Enter Full Name">
                                <div style='color:red; padding: 0 5px;'><?php echo e(($errors->has('name'))?($errors->first('name')):''); ?></div>

                            </div>
                            <div class="form-group">
                                <label>Email address</label>
                                <input name="email" type="email" value="<?php echo e(old('email')); ?>"  class="form-control" placeholder="Enter Email">
                                <div style='color:red; padding: 0 5px;'><?php echo e(($errors->has('email'))?($errors->first('email')):''); ?></div>
                            </div>


                            <div class="form-group">
                                <label>Phone Number</label>
                                <input name="phone" type="number" value="+88<?php echo e(old('phone')); ?>"  class="form-control" placeholder="Enter Phone Number ">
                                <div style='color:red; padding: 0 5px;'><?php echo e(($errors->has('phone'))?($errors->first('phone')):''); ?></div>
                            </div>



                            <div class="form-group"><label>Password</label>
                                <input name="password" type="password" value="<?php echo e(old('password')); ?>" class="form-control" placeholder="Password">
                                <div style='color:red; padding: 0 5px;'><?php echo e(($errors->has('password'))?($errors->first('password')):''); ?></div>

                            </div>



                            <button type="submit"
                                                                                                                                                    class="btn btn-primary mt-4">Register</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Software\Sera-Bangla-The-Ecommerce-Website\resources\views/frontend/user/register.blade.php ENDPATH**/ ?>