<?php $__env->startSection('title'); ?>
     | Material Create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- /.content-header -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6 col-md-12 col-lg-12 d-flex justify-content-end">
                    <a href="<?php echo e(route('material.index')); ?>" class="btn btn-info"> <i class="fa fa-list"> Material Lists </i>  </a>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->


    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Info boxes -->
            <div class="row  py-5">
                <div class="col-12 col-sm-6 col-md-8 mx-auto">
                    <div class="shadow p-3 ">
                        <form action="<?php echo e(route('material.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="material_name"> Material Name: </label>
                                <input type="text" name="material_name" class="form-control" value="<?php echo e(old('material_name')); ?>" id="material_name">
                                <div style='color:red; padding: 0 5px;'><?php echo e(($errors->has('material_name'))?($errors->first('material_name')):''); ?></div>
                            </div>

                            <button type="submit" class="btn btn-success"> Submit </button>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.row -->

        </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Software\Sera-Bangla-The-Ecommerce-Website\resources\views/backend/material/create.blade.php ENDPATH**/ ?>