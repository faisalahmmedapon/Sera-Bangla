<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> সেরা বাংলা <?php echo $__env->yieldContent('title'); ?> </title>
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/assets/css/adminlte.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/assets/css/app.css">
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/assets/css/fontawesome.css">
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/assets/css/OverlayScrollbars.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/assets/css/style.css">
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/assets/css/dataTables.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/assets/css/toastr.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/plugins/summernote/summernote-bs4.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/plugins/select2/select2.min.css"  />


    <?php echo $__env->yieldContent('add_css_in_main_css_place'); ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
<div class="wrapper">
    <!-- Navbar -->
<?php echo $__env->make('backend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Brand Logo -->





        <!-- Sidebar -->

        <?php echo $__env->make('backend.partials.siteber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- /.content-wrapper -->

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->

    <!-- Main Footer -->
<?php echo $__env->make('backend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>


<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<script src="<?php echo e(asset('backend')); ?>/assets/js/jquery-3.5.1.min.js"></script>
<!-- Bootstrap -->
<script src="<?php echo e(asset('backend')); ?>/assets/js/bootstrap.bundle.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?php echo e(asset('backend')); ?>/assets/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('backend')); ?>/assets/js/adminlte.js"></script>



<!-- DataTable -->
<script src="<?php echo e(asset('backend')); ?>/assets/js/datatables.min.js"></script>
<script>
    $(document).ready(function () {
        $('.dataTable').DataTable();
    });
</script>
<!-- DataTable -->





<!-- No image -->
<script src="<?php echo e(asset('backend')); ?>/plugins/noimage/no-image.js"></script>

<!--Product Default image one -->
<script>
    $(document).ready(function() {
        $('#defaultImage').change(function(e) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#showDefaultImage').attr('src', e.target.result);
            }
            reader.readAsDataURL(e.target.files['0']);
        });
    });
</script>



<!-- Toastr -->
<script src="<?php echo e(asset('backend')); ?>/assets/js/toastr.min.js"></script>
<script>
    <?php if(Session::has('message')): ?>
    var type = "<?php echo e(Session::get('alert-type','info')); ?>"

    switch (type) {
        case 'info':
            toastr.info("<?php echo e(Session::get('message')); ?>");
            break;
        case 'success':
            toastr.success("<?php echo e(Session::get('message')); ?>");
            break;
        case 'warning':
            toastr.warning("<?php echo e(Session::get('message')); ?>");
            break;
        case 'error':
            toastr.error("<?php echo e(Session::get('message')); ?>");
            break;
    }
    <?php endif; ?>
</script>
<!-- Toastr -->

<!-- Summernote -->
<script src="<?php echo e(asset('backend')); ?>/plugins/summernote/summernote-bs4.min.js"></script>

<script>
    $(document).ready(function () {
        $('.summernote').summernote();
    });
</script>




<!-- Sweetalert -->
<script src="<?php echo e(asset('backend')); ?>/plugins/sweetalert/sweetalert2@9.js"></script>
<script src="<?php echo e(asset('backend')); ?>/plugins/sweetalert/sweetalertjs.js"></script>



<!-- select2 -->
<script src="<?php echo e(asset('backend')); ?>/plugins/select2/select2.min.js"></script>






<!-- select2 -->
<script>
    $(document).ready(function() {
        $('.myselect2').select2();
    });
</script>



<?php echo $__env->yieldContent('add_js_in_main_js_place'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Software\Sera-Bangla-The-Ecommerce-Website\resources\views/backend/layouts/master.blade.php ENDPATH**/ ?>