<?php $__env->startSection('title'); ?>
    | Products
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- /.content-header -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6 col-md-12 col-lg-12 d-flex justify-content-end">
                    <a href="<?php echo e(route('color.index')); ?>" class="btn btn-info"> <i class="fa fa-list"> All Orders </i> </a>
                    <a href="<?php echo e(route('pending.order')); ?>" class="btn btn-info"> <i class="fa fa-list"> Pending
                            Orders </i> </a>
                    <a href="<?php echo e(route('review.order')); ?>" class="btn btn-info"> <i class="fa fa-list"> Review Orders </i>
                    </a>
                    <a href="<?php echo e(route('accept.order')); ?>" class="btn btn-info"> <i class="fa fa-list"> Accept Orders </i>
                    </a>
                    <a href="<?php echo e(route('confirm.order')); ?>" class="btn btn-info"> <i class="fa fa-list"> Confirm
                            Orders </i> </a>
                    <a href="<?php echo e(route('canceled.order')); ?>" class="btn btn-info"> <i class="fa fa-list"> Canceled
                            Orders </i> </a>
                    <a href="<?php echo e(route('processing.order')); ?>" class="btn btn-info"> <i class="fa fa-list"> Processing
                            Orders </i> </a>
                    <a href="<?php echo e(route('completed.order')); ?>" class="btn btn-info"> <i class="fa fa-list"> Completed
                            Orders </i> </a>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Info boxes -->
            <div class="row">
                <div class="col-12 col-sm-6 col-md-12">
                    <table class="table table-bordered table-active dataTable">

                        <tbody>
                        <tr>
                            <th> Product Name</th>
                            <td width="80%"> <?php echo e($product->product_name); ?> </td>
                        </tr>


                        <tr>
                            <th> Product Quantity</th>
                            <td> <?php echo e($product->product_quantity); ?> </td>
                        </tr>

                        <tr>
                            <th> Product SKU</th>
                            <td> <?php echo e($product->product_sku); ?> </td>
                        </tr>

                        <tr>
                            <th> Product Selling Price</th>
                            <td> $<?php echo e($product->product_selling_price); ?> </td>
                        </tr>

                        <tr>
                            <th> Product Discount Type</th>
                            <td> <?php echo e($product->product_discount_type); ?> </td>
                        </tr>

                        <tr>
                            <th> Product Discount</th>
                            <td> $<?php echo e($product->product_discount); ?> </td>
                        </tr>


                        <tr>
                            <th> Product Discount Price</th>
                            <td> $<?php echo e($product->product_discount_price); ?> </td>
                        </tr>


                        <tr>
                            <th> Product Brand</th>
                            <td> <?php echo e($product_brand->brand_name); ?> </td>
                        </tr>

                        <tr>
                            <th> Product Short Description</th>
                            <td> <?php echo $product->product_short_description; ?> </td>
                        </tr>

                        <tr>
                            <th> Product Description</th>
                            <td> <?php echo $product->product_description; ?> </td>
                        </tr>


                        <tr>
                            <th> Product Specification</th>
                            <td> <?php echo $product->product_specification; ?> </td>
                        </tr>

                        <tr>
                            <th> Product Color</th>
                            <td>
                                <?php $__currentLoopData = $product_colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <button class="btn btn-default"><?php echo e($product_color->color_name); ?></button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </td>
                        </tr>

                        <tr>
                            <th> Product Category</th>
                            <td>
                                <button class="btn btn-default"> <?php echo e($product_category->category_name); ?></button>

                            </td>
                        </tr>

                        <tr>
                            <th> Product Materials</th>
                            <td>
                                <?php $__currentLoopData = $product_materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <button class="btn btn-default"><?php echo e($product_material->material_name); ?></button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                        </tr>

                        <tr>
                            <th> Product Images</th>
                            <td>
                                <?php $__currentLoopData = $product_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <img class="shadow p-2" width="350px" height="170px" src="<?php echo e(asset($data)); ?>">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>

                        </tr>


                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.row -->

        </div>
        <div class="container-fluid py-3">
            <!-- Info boxes -->
            <div class="row">
                <div class="col-12 col-sm-6 col-md-12">
                    <h3> Order Details</h3>
                    <table class="table table-bordered">

                        <tbody>
                        <tr>
                            <th> Order Product Name</th>
                            <td style="width: 80%"> <?php echo e($product->product_name); ?> </td>
                        </tr>


                        <tr>
                            <th> Order Product Quantity</th>
                            <td> <?php echo e($order->product_quantity); ?> </td>
                        </tr>


                        <tr>
                            <th> Order Product Price</th>
                            <td> $<?php echo e($order->product_price); ?> </td>
                        </tr>


                        <tr>
                            <th> Order Product Total Price</th>
                            <td> $<?php echo e($order->product_total_price); ?> </td>
                        </tr>

                        <tr>
                            <th> Order Times</th>
                            <td> <?php echo e($order->created_at->diffForHumans()); ?> </td>
                        </tr>


                        <tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.row -->

        </div>
        <div class="container-fluid py-3">
            <!-- Info boxes -->
            <div class="row">
                <div class="col-12 col-sm-6 col-md-12">
                    <h3> Order Shipping Address Details</h3>
                    <table class="table table-bordered">

                        <tbody>
                        <tr>
                            <th>Name</th>
                            <td style="width: 80%"> <?php echo e($product_shipping_address->f_name); ?> <?php echo e($product_shipping_address->l_name); ?></td>
                        </tr>

                        <tr>
                            <th>Email</th>
                            <td> <?php echo e($product_shipping_address->email); ?> </td>
                        </tr>

                        <tr>
                            <th> Phone Number</th>
                            <td> <?php echo e($product_shipping_address->phone_number); ?> </td>
                        </tr>

                        <tr>
                            <th>Zela</th>
                            <td> <?php echo e($product_shipping_address->zella); ?> </td>
                        </tr>

                        <tr>
                            <th>Upozela</th>
                            <td> <?php echo e($product_shipping_address->upozela); ?> </td>
                        </tr>


                        <tr>
                            <th>Pickup Point</th>
                            <td> <?php echo e($product_shipping_address->picup_point); ?> </td>
                        </tr>
                        <tr>
                            <th>Payment Method</th>
                            <td>
                                <button class="btn-success"><?php echo e($product_shipping_address->payment_method); ?></button>
                            </td>
                        </tr>

                        <tr>
                            <th> Address Save Times</th>
                            <td> <?php echo e($product_shipping_address->created_at->diffForHumans()); ?> </td>
                        </tr>


                        <tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.row -->

        </div>
        <div class="container-fluid py-3">
            <!-- Info boxes -->
            <div class="row">
                <div class="col-12 col-sm-6 col-md-12">
                    <h3> Order Status</h3>
                    <table class="table table-bordered">

                        <tbody>
                        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th> Status</th>
                                <td> <?php echo e($order_status->order_status); ?> </td>
                                <td> <?php echo e($order_status->created_at->diffForHumans()); ?> </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="float-right">
                        <form action="<?php echo e(route('order.status.change')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="order_id" value="<?php echo e($order_status->order_id); ?>">
                            <input type="hidden" name="user_id" value="<?php echo e($order_status->user_id); ?>">
                            <input type="hidden" name="payment_method" value="<?php echo e($order_status->payment_method); ?>">
                            <input type="hidden" name="amount" value="<?php echo e($order_status->amount); ?>">
                            <input type="hidden" name="payment_status" value="<?php echo e($order_status->payment_status); ?>">
                            <select class="form-select" aria-label="Default select example" name="order_status">
                                <option <?php if($order_status == 'pending'): ?> selected <?php endif; ?> value="pending">Pending</option>
                                <option <?php if($order_status == 'Order Review'): ?> selected <?php endif; ?> value="Order Review">Order
                                    Review
                                </option>
                                <option <?php if($order_status == 'Accept'): ?> selected <?php endif; ?> value="Accept">Accept</option>
                                <option <?php if($order_status == 'Confirm'): ?> selected <?php endif; ?> value="Confirm">Confirm</option>
                                <option <?php if($order_status == 'Canceled'): ?> selected <?php endif; ?> value="Canceled">Canceled
                                </option>
                                <option <?php if($order_status == 'Processing'): ?> selected <?php endif; ?> value="Processing">
                                    Processing
                                </option>
                                <option <?php if($order_status == 'Completed'): ?> selected <?php endif; ?> value="Completed">Completed
                                </option>
                            </select>
                            <button type="submit">Change</button>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.row -->

        </div>
        <div class="container-fluid py-3">
            <!-- Info boxes -->
            <div class="row">
                <div class="col-12 col-sm-6 col-md-12">
                    <h3> Order User Information</h3>
                    <table class="table table-bordered">

                        <tbody>
                        <tr>
                            <th> Name</th>
                            <td width="80%"> <?php echo e($user->name); ?> </td>
                        </tr>

                        <tr>
                            <td>Email:</td>
                            <td><?php echo e($user->email); ?>

                                <?php if($user->email_verified_at != null): ?>
                                    <p class=" bg-success text-white p-1"> Email Verified</p>
                                <?php else: ?>
                                    <p class=" bg-danger text-white p-1"> Email Not Verified</p>
                                <?php endif; ?>
                            </td>
                        </tr>

                        <tr>
                            <td>Phone:</td>
                            <td><?php echo e($user->phone); ?>

                                <?php if($user->phone_verified_at != null): ?>
                                    <p class=" bg-success text-white p-1"> Phone Verified</p>
                                <?php else: ?>
                                    <p class=" bg-danger text-white p-1"> Phone Not Verified</p>
                                <?php endif; ?>

                            </td>
                        </tr>

                        <tr>
                            <td>Gender:</td>
                            <td><?php echo e($user->gender); ?></td>
                        </tr>

                        <tr>
                            <td>Address:</td>
                            <td><?php echo e($user->address); ?></td>
                        </tr>


                        <tr>
                            <td>Image:</td>
                            <td><img height="100px" width="200px" src="<?php echo e($user->image); ?>"></td>
                        </tr>

                        <tr>
                            <td>Profile Status :</td>
                            <td><?php if($user->status == '1'): ?> <a class=" bg-success text-white p-1">Active</a> <?php else: ?>
                                    <a class="bg-danger text-white p-1">Inactive</a>                         <p> Your
                                        account has been disabled . Please Contact in support team.</p>
                                <?php endif; ?>
                            </td>
                        </tr>

                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.row -->

        </div>
    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Software\Sera-Bangla-The-Ecommerce-Website\resources\views/backend/order/details.blade.php ENDPATH**/ ?>