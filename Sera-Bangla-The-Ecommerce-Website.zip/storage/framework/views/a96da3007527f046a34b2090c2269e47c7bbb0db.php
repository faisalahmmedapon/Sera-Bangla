<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <?php echo $__env->make('frontend.partials.dashboard_siteber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

                <div class="col-md-8">

                    <div class="card" style="border:1px solid #ddd;">
                        <div class="card-header bg-light"><?php echo e(__('Verify Your Email Address')); ?></div>

                        <div class="card-body" style="padding:20px">
                            <?php if(session('resent')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                                </div>
                            <?php endif; ?>

                            <?php echo e(__('Before proceeding, please check your email for a verification link.')); ?>

                            <?php echo e(__('If you did not receive the email')); ?>,
                            <form class="d-inline" method="POST" action="<?php echo e(route('email.verification.send')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                        class="btn btn-link p-0 m-0 align-baseline"><?php echo e(__('verify')); ?></button>
                                .
                            </form>
                        </div>
                    </div>
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Software\Sera-Bangla-The-Ecommerce-Website\resources\views/frontend/user/email_verify.blade.php ENDPATH**/ ?>