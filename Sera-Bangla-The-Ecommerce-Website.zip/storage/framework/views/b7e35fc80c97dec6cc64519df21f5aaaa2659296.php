<?php $__env->startSection('content'); ?>

    <?php if($cartItems->count() > 0): ?>

        <div class="site__body">
            <div class="cart block">
                <div class="container">
                    <table class="cart__table cart-table">
                        <thead class="cart-table__head">
                        <tr class="cart-table__row">
                            <th class="cart-table__column cart-table__column--image">Image</th>
                            <th class="cart-table__column cart-table__column--product">Product</th>
                            <th class="cart-table__column cart-table__column--price">Price</th>
                            <th class="cart-table__column cart-table__column--quantity">Quantity</th>
                            <th class="cart-table__column cart-table__column--total">Total</th>
                            <th class="cart-table__column cart-table__column--remove"></th>
                        </tr>
                        </thead>
                        <tbody class="cart-table__body">


                        <?php if($cartItems): ?>
                            <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php
                                $product = App\Models\Product::where('id', $item->id)->first();
                                $product_images = json_decode($product->product_image);
                                $product_images_one = $product_images[0];
                                //dd($product_images_one)
                                ?>

                                <tr class="cart-table__row">
                                    <td class="cart-table__column cart-table__column--image"><a href="#"><img
                                                src="<?php echo e(asset($product_images_one)); ?>" alt=""></a></td>
                                    <td class="cart-table__column cart-table__column--product"><a href="#"
                                                                                                  class="cart-table__product-name"><?php echo e($item->name); ?></a>




                                    </td>
                                    <td class="cart-table__column cart-table__column--price" data-title="Price">
                                        ৳ <?php echo e($item->price); ?> </td>
                                    <td class="cart-table__column cart-table__column--quantity" data-title="Quantity">
                                        <div class="input-number">

                                            
                                            
                                            
                                            

                                            <form action="<?php echo e(route('cart.update')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                                <div class="d-flex">
                                                    <input style="width: 50px" type="number" name="quantity"
                                                           value="<?php echo e($item->quantity); ?>"
                                                           class="w-6 text-center bg-gray-300"/>
                                                    <button type="submit" class="btn btn-primary cart__update-button">
                                                        update
                                                    </button>
                                                </div>
                                            </form>

                                        </div>
                                    </td>
                                    <td class="cart-table__column cart-table__column--total" data-title="Total">
                                        ৳ <?php echo e($item->price*$item->quantity); ?></td>
                                    <td class="cart-table__column cart-table__column--remove">
                                        
                                        
                                        
                                        
                                        
                                        <form action="<?php echo e(route('cart.remove')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" value="<?php echo e($item->id); ?>" name="id">
                                            <button class="btn btn-primary cart__update-button">x</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="cart__actions">
                        <form class="cart__coupon-form"><label for="input-coupon-code" class="sr-only">Password</label>
                            <input type="text" class="form-control" id="input-coupon-code" placeholder="Coupon Code">
                            <button type="submit" class="btn btn-primary">Apply Coupon</button>
                        </form>
                        <div class="cart__buttons"><a href="<?php echo e(route('continue.shopping')); ?>"
                                                      class="btn btn-primary cart__update-button">Continue Shopping</a>

                        </div>
                    </div>
                    <div class="row justify-content-end pt-5">
                        <div class="col-12 col-md-7 col-lg-6 col-xl-5">
                            <div class="card">
                                <div class="card-body"><h3 class="card-title">Cart Totals</h3>
                                        <table class="cart__totals">
                                            <thead class="cart__totals-header">
                                            <tr>
                                                <th>Subtotal</th>
                                                <td>৳ <?php echo e(\Cart::getSubTotal('0')); ?></td>
                                            </tr>
                                            </thead>
                                            <tbody class="cart__totals-body">
                                            <tr>
                                                <th>Shipping</th>
                                                <td> ৳ 25x<?php echo e($item->quantity); ?> = ৳ <?php echo e($item->quantity*25); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <th>Tax</th>
                                                <td>৳ 0.00</td>
                                            </tr>
                                            </tbody>
                                            <tfoot class="cart__totals-footer">
                                            <tr>
                                                <th>Pay</th>
                                                <td>৳ <?php echo e(\Cart::getSubTotal('0')+$item->quantity*25); ?></td>
                                            </tr>
                                            </tfoot>
                                        </table>

                                    <a class="btn btn-primary btn-xl btn-block cart__checkout-button"
                                       href="<?php echo e(route('order.checkout')); ?>">Proceed
                                        to checkout</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <p class="text-center p-4 bg-light"> Please Add some product in your cart</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Software\Sera-Bangla-The-Ecommerce-Website\resources\views/frontend/cart/cart.blade.php ENDPATH**/ ?>