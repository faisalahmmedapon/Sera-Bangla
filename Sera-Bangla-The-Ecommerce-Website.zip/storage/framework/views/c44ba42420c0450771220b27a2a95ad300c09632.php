<?php $__env->startSection('title'); ?>
    | Colors
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6 col-md-12 col-lg-12 d-flex justify-content-end">
                    <a href="<?php echo e(route('color.create')); ?>" class="btn btn-success"> <i class="fa fa-plus"> New Color </i> </a>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Info boxes -->
            <div class="row">
                <div class="col-12 col-sm-6 col-md-12">
                    <table class="table table-bordered table-active dataTable">
                        <thead>
                        <tr>
                            <th scope="col">SL</th>
                            <th scope="col"> Color Name</th>
                            <th scope="col"> Action </th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($key+1); ?></th>
                            <td><?php echo e($color->color_name); ?></td>
                            <td>
                                <?php if($color->status == 1): ?>
                                    <a href="<?php echo e(route('color.status',$color->id)); ?>" class="btn"> <i class="fa fa-thumbs-up"> </i> </a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('color.status',$color->id)); ?>" class="btn"> <i class="fa fa-thumbs-down"> </i> </a>
                                <?php endif; ?>
                                    <a href="<?php echo e(route('color.edit',$color->id)); ?>" class="btn"> <i class="fa fa-edit"> </i> </a>
                                <a href="<?php echo e(route('color.delete',$color->id)); ?>" class="btn"> <i class="fa fa-trash"> </i> </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.row -->

        </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Software\Sera-Bangla-The-Ecommerce-Website\resources\views/backend/color/index.blade.php ENDPATH**/ ?>