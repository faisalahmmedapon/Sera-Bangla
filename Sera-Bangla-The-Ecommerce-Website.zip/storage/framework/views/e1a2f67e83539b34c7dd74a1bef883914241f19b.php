<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <?php echo $__env->make('frontend.partials.dashboard_siteber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md-9">
               <table class="table table-bordered">
                   <thead>
                   <tr>
                       <td>Id</td>
                       <td>Product</td>
                       <td> Quantity</td>
                       <td> Price</td>
                       <td> Status </td>
                       <td>Action</td>
                   </tr>
                   </thead>
                   <tbody>
                   <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                       <td> <?php echo e($key+1); ?> </td>
                       <td> <?php echo e(Str::limit($order->product_name,100)); ?> </td>
                       <td> <?php echo e($order->product_quantity); ?> </td>
                       <td> Tk <?php echo e($order->product_total_price); ?> </td>
                       <td> <?php echo e($order->status); ?> </td>


                       <?php
                       $date = $order->created_at;

                       $date = Carbon\Carbon::parse($date); // now date is a carbon instance
//                       $elapsed = $date->diffForHumans(Carbon\Carbon::now());
                       $elapsed = $date->diffForHumans();
                       ?>
                       <td> <?php echo e($elapsed); ?></td>
                   </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
               </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Software\Sera-Bangla-The-Ecommerce-Website\resources\views/frontend/order/order.blade.php ENDPATH**/ ?>