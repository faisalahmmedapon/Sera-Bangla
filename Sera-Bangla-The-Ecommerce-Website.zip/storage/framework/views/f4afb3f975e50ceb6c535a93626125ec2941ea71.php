<?php $__env->startSection('title'); ?>
     | Brand edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6 col-md-12 col-lg-12 d-flex justify-content-end">
                    <a href="<?php echo e(route('category.index')); ?>" class="btn btn-info"> <i class="fa fa-list"> Category Lists </i>  </a>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Info boxes -->
            <div class="row  py-5">
                <div class="col-12 col-sm-6 col-md-8 mx-auto">
                    <div class="shadow p-3">
                        <form action="<?php echo e(route('brand.update',$brand->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="brand_name"> Brand Name: </label>
                                <input type="text" name="brand_name" class="form-control" value="<?php echo e($brand->brand_name); ?>" id="brand_name">
                                <div style='color:red; padding: 0 5px;'><?php echo e(($errors->has('brand_name'))?($errors->first('brand_name')):''); ?></div>
                            </div>
                            <div class="form-group">
                                <label for="brand_logo"> Brand Logo: </label>
                                <input type="file" name="brand_logo" class="form-control" id="brand_logo">
                            </div>

                            <div class="form-group">
                                <label for="coupon_id"> Coupon List </label>
                                <select class="form-control" name="coupon_id">
                                    <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($coupon->id == $brand->coupon_id ): ?> selected <?php endif; ?>  value="<?php echo e($coupon->id); ?>"> <?php echo e($coupon->coupon_name); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </div>
                            <button type="submit" class="btn btn-success"> Submit </button>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.row -->

        </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Software\Sera-Bangla-The-Ecommerce-Website\resources\views/backend/brand/edit.blade.php ENDPATH**/ ?>